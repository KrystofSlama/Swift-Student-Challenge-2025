Hello my name is Kryštof Sláma (Christopher). I'm a passionate iOS developer and a Swift Student Challenge winner(2024) now aming to be distinguished winner, currently studying Informatics. I love building projects that make learning more engaging, and LogicLab is my way of helping others grasp the beauty of algorithms in a fun and interactive way.

LogicLab is an interactive learning app designed to help users understand basics of fundamental computer science concepts through visualizations and hands-on experimentation. Whether you're a beginner or an experienced developer, LogicLab provides an engaging way to explore sorting, searching, and other key algorithms.

LogicLab was made by me only with no external help. I tested it on my iPad Air M1, everything seems to be working just fine. With drag and drop sometimes there is glitching, but working on that was very deep programing out of my level and I was glad that it works.


USAGE - LogicLab is meant to be used in Landscape mode!!!
